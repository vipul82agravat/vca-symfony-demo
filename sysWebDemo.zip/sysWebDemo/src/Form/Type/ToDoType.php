<?php
// src/Form/Type/TaskType.php
namespace App\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\Form\FormError;

class ToDoType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('name', TextType::class)
            ->add('startdate', DateType::class, [
                    'widget' => 'single_text',
                    'html5' => true,
                    'attr' => [
                        'class' => 'js-datepicker'
                        ]])
                        
            ->add('note', TextareaType::class)
            ->add('location', TextType::class)
            ->add('status', ChoiceType::class, [
                'choices'  => [
                    'Select status' => null,
                    'Active' => 0,
                    'InActive' => 1,
                ],'help'=>'Default status is Active now every time'
            ])
            ->add('save', SubmitType::class)
            ->addEventListener(
                FormEvents::PRE_SET_DATA,
                [$this, 'onPreSetData']
            )->addEventListener(
                FormEvents::POST_SET_DATA,
                [$this, 'onPostSetData']
            )
            ->addEventListener(
                FormEvents::PRE_SUBMIT,
                [$this, 'onPreSubmit']
            )
            ->addEventListener(
                FormEvents::POST_SUBMIT,
                [$this, 'onPostSubmit']
            )
            ->add('save', SubmitType::class,['label' => 'Add TodoList'])
            ;
    }
      // form event for pre set data
      public function onPreSetData(FormEvent $event): void
      {
          
          echo "<br>";
          echo "onPreSetData EventListener event is call";
          echo "<br>";
          // ...
      }
      // form event for post set data
      
      public function onPostSetData(FormEvent $event): void
      {
          
          echo "onPostSetData EventListener event is call";
          // ...
      }
      // form event for pre submit data
      
      public function onPreSubmit(FormEvent $event): void
      {
                echo "<br>";
                echo "onPreSubmit EventListener event is call";
                echo "<br>";
        // ...
              $form = $event->getForm();
              $formdata=$event->getData();
              $taskname=$formdata['name'];  
              $startdate=$formdata['startdate'];  
              $note=$formdata['note'];  
              $today=date('Y-m-d');

              if (strlen($taskname) < 2 or strlen($taskname) > 7){
  
                  echo "error name must is greater then 2 and lesss then 7 ";
                  $form->setData('name')->addError(new FormError('error name must is greater then 2 and lesss then 7'));
                   
                }
                if ($startdate < $today  or $startdate == $today ) {
                    echo "error end date is not less then start date please check";
                    $form->setData('startdate')->addError(new FormError('error end date is not less then start date please check '));
                } 
              
                if(strlen($note) < 3){
                    echo "error note  must is greter then 3 value";
                    $form->setData('note')->addError(new FormError('error note  must is greter then 3 value'));
                }
        }
      // form event for prposte submit data
      
      public function onPostSubmit(FormEvent $event): void
      {
          //  $routeParams = $request->attributes->get('user_task_add_form');
           
              $form=$event->getForm();
  
              if($form->isValid()){
                   return;
              }
              else{
                 $form->getErrors(true, false);
               
              }
                echo "<br>";
                echo "onPostSubmit EventListener event is call";
                echo "<br>";
         //dd('onPostSubmit');
          // ...
      }
}