<?php

namespace App\Controller;


use App\Entity\TodoLIST;
use App\Form\Type\ToDoType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Form\Form;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\Persistence\ManagerRegistry;
use Doctrine\ORM\EntityManagerInterface;

class ToDoListController extends AbstractController
{
    #[Route('/todo/list', name: 'app_to_do_list')]
    public function index(EntityManagerInterface $entityManager): Response
    {
        dump('vipul');
        
        $repository = $entityManager->getRepository(TodoLIST::class);
        $todoList=$repository->findAll();
        $dataList=[];
        foreach($todoList as $key=>$list){
            $dataList[$key]['id']=$list->getId();
            $dataList[$key]['name']=$list->getName();
            $dataList[$key]['startdate']=date_format($list->getStartdate(),'Y-m-d');
            $dataList[$key]['note']=$list->getNote();
        }
        dump($dataList);
        return $this->render('to_do_list/index.html.twig', [
            'todoList' => $dataList,
        ]);
    }
    public function addToDo(Request $request,ManagerRegistry $doctrine): Response
    {
        $entityManager = $doctrine->getManager();
        $todo = new TodoLIST();
        $todo->getName('Write a blog post');
        $todo->setStartdate(new \DateTime('tomorrow'));
        $todo->setNote('');

        $form = $this->createForm(ToDoType::class, $todo);
        
        $form->handleRequest($request);
       dump($form);
        if ($form->isSubmitted() && $form->isValid()) {
            $todo = $form->getData();
            
            $entityManager->persist($todo);
            // actually executes the queries (i.e. the INSERT query)
            $entityManager->flush();
            // ... perform some action, such as saving the task to the database
            return $this->redirectToRoute('app_to_do_list');
        }
        else if($form->isSubmitted() && !$form->isValid()){
            //  dd($form->getErrors());
        }
        
        
        return $this->renderForm('to_do_list/addToDo.html.twig', [
            'form' => $form,
        ]);
    }
    #[Route('todo_delete/{id}', name: 'todo_delete')]
    public function toDoDelete(EntityManagerInterface $entityManager,int $id): Response
    {
        $repository = $entityManager->getRepository(TodoLIST::class);
        $todoData=$repository->find($id);
        
        $entityManager->remove($todoData);
        $entityManager->flush();
            if (!$todoData) {
                throw $this->createNotFoundException(
                    'No User found for id '.$id
                );
            }
        return $this->redirectToRoute('app_to_do_list');
    }
    #[Route('todo_edit/{id}', name: 'todo_edit')]
    public function toDoEdit(Request $request,EntityManagerInterface $entityManager,int $id): Response
    {
        $repository = $entityManager->getRepository(TodoLIST::class);
        $todoData=$repository->find($id);
        
        
        $todoData->getName($todoData->getName());
        $todoData->setStartdate(new \DateTime('tomorrow'));
        $todoData->setNote($todoData->getNote());

        $form = $this->createForm(ToDoType::class, $todoData);
        
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {

            $todoData = $form->getData();
            
            $entityManager->persist($todoData);
            // actually executes the queries (i.e. the INSERT query)
            $entityManager->flush();
            // ... perform some action, such as saving the task to the database
            return $this->redirectToRoute('app_to_do_list');
        }
        
        
        return $this->renderForm('to_do_list/addToDo.html.twig', [
            'form' => $form,
        ]);
    }
}
