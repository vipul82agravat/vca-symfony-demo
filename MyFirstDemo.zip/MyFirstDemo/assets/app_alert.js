import $ from 'jquery';

$( document ).ready(function() {
     alert('hii re call done');
});
