p {
    color:blur;
}